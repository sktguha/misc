const robot = require('robotjs');

function moveAndClick(){
    // robot.moveMouse(0,0);
    // TODO: add increments of x coords so can adjust quickly
    const x = 1342;
    robot.moveMouse(x, 10);
    robot.mouseClick();
    robot.moveMouse(x, 80);
    robot.mouseClick();
    robot.moveMouse(x+60, 120);
}
moveAndClick();

// const ioHook = require('iohook');

// ioHook.on('keydown', (event) => {
//   console.log(event); // { type: 'mousemove', x: 700, y: 400 }
// });