import os
print "hello world"
os.system("node /Users/saikatguha/Documents/personal_private_projects/flux/index.js")