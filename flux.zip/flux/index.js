const robot = require('robotjs');

async function delay(ms){
    await new Promise((resolve, reject)=>setTimeout(()=>resolve(),ms))
}

async function others(){
    // robot.moveMouse(0,0);
    // TODO: add increments of x coords so can adjust quickly
    const x = 1342 - (36*4);
    if(process.argv[2]){
        robot.moveMouse(x-9, 25+9);  
        await delay(200);
        robot.mouseClick();
        return;  
    }
    robot.moveMouse(x, 10);
    robot.mouseClick();
    robot.moveMouse(x, 80);
    robot.mouseClick();
    robot.moveMouse(x+120+60, 150-20);
}
async function moveAndClick(x,y){
    robot.moveMouse(x, y);
    await delay(200);
    robot.mouseClick();
}
if(process.argv[2]==="music"){
    moveAndClick(600+(28*4)+10,1140-60);
    delay(800);
    robot.keyTap('up','command');
} else{
    others();
}

console.log('got:',process.argv[2])
// const ioHook = require('iohook');

// ioHook.on('keydown', (event) => {
//   console.log(event); // { type: 'mousemove', x: 700, y: 400 }
// });