// ==UserScript==
// @name         shazam youtube open
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.shazam.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
     window.onload = ()=>{
        var el = document.getElementById('yt-videocontainer');
        if(!el){ console.log({el}, ' not found ')};
        location.href = el.getAttribute('data-href');
     }
    // Your code here...
})();