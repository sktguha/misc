// ==UserScript==
// @name         New Userscript
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @include        /^https://quantumk.foundation*
// @include        /^https://quantumk-ae.foundation*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
      window.onload = ()=>{
          document.getElementById('username') && (document.getElementById('username').value = 'sguha') && document.querySelectorAll('input[type=submit]')[0].click();
          document.getElementById('password') && (document.getElementById('password').value = 'SoftOrchidChocolate6') && document.querySelectorAll('input[type=submit]')[0].click();
      };
    // Your code here...
})();