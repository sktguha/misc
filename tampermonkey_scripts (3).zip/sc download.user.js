// ==UserScript==
// @name         sc download
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://sctomp3.net/*
// ==/UserScript==

(function() {
    'use strict';
     window.onload = function(){
       document.querySelector('input[name=url]').value = location.href.split('?')[1].split('&').find(f=>f.includes('url=')).split('=')[1];
       document.querySelector('.btn-primary').click()
     }
    // Your code here...
})();