// ==UserScript==
// @name         find red td game
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://kamal.com/
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
     window.onload=()=>{
var gt = (m=60,n=60)=>{
var tab = document.createElement('table');
Array(m).fill(1).forEach((a,i)=>{
  var tr = document.createElement('tr');
  Array(n).fill(1).forEach((a,j)=>{
     var td = document.createElement('td');
     td.style.cursor = "pointer";
     td.innerText = '*';
     td.onclick = ()=>alert('this is not red. try again');
     tr.appendChild(td);
  })
  tab.appendChild(tr)
})
  var tds = tab.querySelectorAll('td');
  var mtd = tds[Math.floor(Math.random()*tds.length)]
  mtd.style="color:red";
  console.log({mtd})
  mtd.onclick = ()=>{
    alert('game won!. click ok to try again');
    document.body.innerHTML = "";
document.body.appendChild(gt(100,100))
  };
return tab;
}
document.body.innerHTML = "";
document.body.appendChild(gt(100,100))
     }
    // Your code here...
})();