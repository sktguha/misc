// ==UserScript==
// @name         dailywtf new tab
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://thedailywtf.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
     window.onload = () =>{
         console.log('load');
     document.querySelectorAll('a').forEach(a=>a.target = '_blank');
     }
    // Your code here...
})();