// ==UserScript==
// @name         HN comments hide
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://news.ycombinator.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
     window.onload = ()=>{
         window.hf = !window.hf; [...document.querySelectorAll('.ind')].filter(el=> el.firstChild.width !== 0).forEach(td => td.parentElement.style.display =window.hf?"none":"block");
     }
    // Your code here...
})();