// ==UserScript==
// @name         Meet remove overlay
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://meet.google.com/*
// @grant        none
// ==/UserScript==



(async function() {
    'use strict';
    var certainQuery = (q,t=700,expiry=20000) => new Promise((res) => {
    var fn = ()=> { var rs = document.querySelectorAll(q); if(rs.length) { res(rs) } else setTimeout(fn,t); }
     fn();
     setTimeout(()=>fn=()=>{},expiry);
    })
//    certainQuery('.Ce1Y1c',400).then(el=>{
      //  el[0].click();
    //    certainQuery('.Ce1Y1c',400).then(el=>el[0].click());
  //  });
//    certainQuery('.CwaK9',400).then(el=>el[0].click());
    var id= setInterval(()=>{
        //console.log('ping');
       document.querySelector('.Ce1Y1c')?.click();
       document.querySelector('.CwaK9')?.click();
    },500);
    setTimeout(()=>{clearInterval(id); console.log('clearinterval',id);},15000);

     //window.onload = ()=>{ const el = document.querySelectorAll('.Ce1Y1c')[0]; if(!el) { return;} el.click(); /* certainQuery('.RveJvd.snByac',30).then(el2 => el2[0].click());*/}
    // Your code here...
})();