// ==UserScript==
// @name         youtube mp3
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.easymp3converter.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

   document.getElementById('search_txt').value = location.href.split("?url=")[1];
setTimeout(()=>{
document.getElementById('btn-submit').click();
const fn = ()=>{
//  debugger;
 var sel = document.getElementById('video_types');
 if(!sel){ setTimeout(fn,700); return;}
//  debugger;
 var link = sel.getElementsByTagName('option')[0].getAttribute('data-link');
 var a = document.createElement("a");
 a.href = link;
 a.click()
 setTimeout(()=>window.close(),5000);
};
 fn();
}, 600);

    // Your code here...
})();